In order to run it.
1. Install python
2. Go to the terminal and go to the directory where the program is
3. run command 'python main.py'
4. exceute commands
5. enter 'exit' to come out of the program

